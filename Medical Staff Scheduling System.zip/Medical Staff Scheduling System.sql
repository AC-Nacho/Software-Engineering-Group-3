CREATE TABLE Facility (
    facilityID INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    address VARCHAR(100),
    phoneNum VARCHAR(20)
);


CREATE TABLE MedicalStaff (
    StaffID INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(50),
    fname VARCHAR(50),
    lname VARCHAR(50),
    createdAt INT,
    facilityID INT,
    FOREIGN KEY (facilityID) REFERENCES Facility(facilityID)
);


CREATE TABLE Patient (
    PatientID INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50),
    password VARCHAR(50),
    fname VARCHAR(50),
    lname VARCHAR(50),
    SSN VARCHAR(11),
    DOB DATE,
    phoneNum VARCHAR(20),
    address VARCHAR(100)
);



CREATE TABLE Doctor (
    doctorID INT AUTO_INCREMENT PRIMARY KEY,
    fname VARCHAR(50),
    lname VARCHAR(50),
    phoneNum VARCHAR(20),
    specialty VARCHAR(60),
    facilityID INT,
    FOREIGN KEY (facilityID) REFERENCES Facility(facilityID)
);


CREATE TABLE Department (
    depID INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    facilityID INT,
    FOREIGN KEY (facilityID) REFERENCES Facility(facilityID)
);


CREATE TABLE Appointment (
    ApptID INT AUTO_INCREMENT PRIMARY KEY,
    doctorID INT,
    patientID INT,
    apptDate DATE,
    apptTime TIME,
    status VARCHAR(50),
    facilityID INT,
    FOREIGN KEY (doctorID) REFERENCES Doctor(doctorID),
    FOREIGN KEY (patientID) REFERENCES Patient(PatientID),
    FOREIGN KEY (facilityID) REFERENCES Facility(facilityID)
);