import java.sql.*;

public class dbExample {
    public static void main(String[] args) {
        try {
            Connection con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/medicalappt", "root", "samphan98");
            System.out.println("Connected successfully.");

            // Create Statement
            Statement stmt = con.createStatement();
            
         // ---------------- RETRIEVAL ----------------
            String selectSQL = "SELECT PatientID, username, fname, lname, phoneNum, address FROM patient";

            System.out.println("Executing select...");
            ResultSet rs = stmt.executeQuery(selectSQL);

            // Print out the result
            System.out.println("Patient List:");
            while (rs.next()) {
                int patientId = rs.getInt("PatientID");
                String username = rs.getString("username");
                String fname = rs.getString("fname");
                String lname = rs.getString("lname");
                String phoneNum = rs.getString("phoneNum");
                String address = rs.getString("address");

                System.out.println("ID: " + patientId + ", Username: " + username + 
                                   ", Name: " + fname + " " + lname + 
                                   ", Phone: " + phoneNum + 
                                   ", Address: " + address);
            }

            rs.close(); // Close ResultSet

            // ---------------- INSERTION ----------------
//            String insertSQL = "INSERT INTO patient ( username, password, fname, lname, SSN, DOB, phoneNum, address) " +
//                               "VALUES ('bobbylee', 'pass123', 'bobby', 'lee', '123-12-1234', '2024-04-14', '555-555-5555', '456 Neymar Jr')";
//            System.out.println("Executing insert...");
//            int rows = stmt.executeUpdate(insertSQL);
//            if (rows > 0) {
//                System.out.println("Patient has been inserted.");
//            } else {
//                System.out.println("The insertion failed! No rows affected.");
//            }

            // ---------------- DELETION ----------------
//            int patientIdToDelete = 9;
//            String deleteSQL = "DELETE FROM patient WHERE PatientID = " + patientIdToDelete;
//            System.out.println("Executing delete...");
//            int rows = stmt.executeUpdate(deleteSQL);
//            if (rows > 0) {
//                System.out.println("Patient has been deleted.");
//            } else {
//                System.out.println("Deletion failed! No rows matched.");
//            }

//            // ---------------- UPDATE ----------------
//            int patientIdToUpdate = 1; // specify which PatientID you want to update
//            String newPhoneNumber = "999-999-9999";
//            String newAddress = "123 Messi Lane";
//
//            String updateSQL = "UPDATE patient SET phoneNum = '" + newPhoneNumber + "', address = '" + newAddress + 
//                               "' WHERE PatientID = " + patientIdToUpdate;
//
//            System.out.println("Executing update...");
//            int rows = stmt.executeUpdate(updateSQL);
//
//            if (rows > 0) {
//                System.out.println("Patient has been updated.");
//            } else {
//                System.out.println("Update failed! No rows matched.");
//            }
//
//            // Close resources
//            stmt.close();
            con.close();

        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
