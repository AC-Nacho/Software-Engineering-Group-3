NSERT INTO Facility (name, address, phoneNum) VALUES
('Greenwood Health Center', '101 Main St, Chicago, IL', '312-555-0101'),
('Riverdale Medical', '202 Oak Ave, Boston, MA', '617-555-0202'),
('Sunset Clinic', '303 Pine Rd, Miami, FL', '305-555-0303'),
('Hilltop Hospital', '404 Maple Blvd, Seattle, WA', '206-555-0404'),
('Lakeside Health', '505 Birch Ln, Denver, CO', '720-555-0505');
[9:32 PM]
INSERT INTO MedicalStaff (username, password, fname, lname, createdAt, facilityID) VALUES
('sroberts', 'pass1', 'Sarah', 'Roberts', 20240401, 1),
('mjackson', 'pass2', 'Mark', 'Jackson', 20240402, 2),
('kthomas', 'pass3', 'Karen', 'Thomas', 20240403, 3),
('bwilliams', 'pass4', 'Brian', 'Williams', 20240404, 4),
('ajames', 'pass5', 'Amanda', 'James', 20240405, 5);
[9:32 PM]
INSERT INTO Patient (username, password, fname, lname, SSN, DOB, phoneNum, address) VALUES
('tallen', 'pwd1', 'Tom', 'Allen', '111-22-3333', '1985-07-12', '312-555-1111', '10 Clark St, Chicago, IL'),
('nlee', 'pwd2', 'Nina', 'Lee', '222-33-4444', '1992-03-25', '617-555-2222', '20 Forest Ave, Boston, MA'),
('dpatel', 'pwd3', 'Dinesh', 'Patel', '333-44-5555', '1978-11-30', '305-555-3333', '30 Palm Dr, Miami, FL'),
('hmorris', 'pwd4', 'Helen', 'Morris', '444-55-6666', '2000-01-18', '206-555-4444', '40 Hilltop Rd, Seattle, WA'),
('sfernandez', 'pwd5', 'Sofia', 'Fernandez', '555-66-7777', '1995-09-09', '720-555-5555', '50 Lakeview Ln, Denver, CO');
[9:33 PM]
INSERT INTO Doctor (fname, lname, phoneNum, specialty, facilityID) VALUES
('James', 'Anderson', '312-555-1000', 'Cardiology', 1),
('Rachel', 'Nguyen', '617-555-2000', 'Dermatology', 2),
('Ethan', 'Wright', '305-555-3000', 'Orthopedics', 3),
('Olivia', 'Brown', '206-555-4000', 'Pediatrics', 4),
('Liam', 'Garcia', '720-555-5000', 'Neurology', 5);
[9:33 PM]
INSERT INTO Department (name, facilityID) VALUES
('Cardiology', 1),
('Dermatology', 2),
('Orthopedics', 3),
('Pediatrics', 4),
('Neurology', 5);
[9:33 PM]
INSERT INTO Appointment (doctorID, patientID, apptDate, apptTime, status, facilityID) VALUES
(1, 1, '2025-05-10', '09:00:00', 'Scheduled', 1),
(2, 2, '2025-05-11', '10:30:00', 'Confirmed', 2),
(3, 3, '2025-05-12', '11:45:00', 'Completed', 3),
(4, 4, '2025-05-13', '14:00:00', 'Scheduled', 4),
(5, 5, '2025-05-14', '15:15:00', 'Canceled', 5);